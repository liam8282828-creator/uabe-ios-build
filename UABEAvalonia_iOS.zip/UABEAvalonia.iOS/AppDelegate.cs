using Avalonia;
using Avalonia.iOS;
using Foundation;
using UIKit;

namespace UABEAvalonia.iOS;

/// <summary>
/// Punto de entrada de la aplicación en iOS.
/// Avalonia gestiona la ventana principal; UIKit solo arranca el ciclo de vida.
/// </summary>
[Register("AppDelegate")]
public class AppDelegate : AvaloniaAppDelegate<App>
{
    protected override AppBuilder CustomizeAppBuilder(AppBuilder builder)
    {
        return base.CustomizeAppBuilder(builder)
            .WithInterFont()
            .UseReactiveUI()
            .LogToTrace();
    }

    /// <summary>
    /// iOS llama a este método cuando el usuario abre un archivo externo
    /// (por ejemplo, desde la app "Archivos" o mediante AirDrop).
    /// Se delega al MainViewModel para abrir el archivo de forma segura con FileStream.
    /// </summary>
    public override bool OpenUrl(UIApplication app, NSUrl url, NSDictionary options)
    {
        if (url.IsFileUrl)
        {
            // Asegurar acceso al archivo en el sandbox de iOS
            bool securityScoped = url.StartAccessingSecurityScopedResource();
            try
            {
                var localPath = url.Path;
                if (localPath != null && App.MainViewModel != null)
                {
                    // Abre el archivo usando el sistema de FileStream segmentado
                    // para evitar cargar todo el bundle en RAM
                    App.MainViewModel.OpenFileFromPath(localPath);
                }
            }
            finally
            {
                if (securityScoped)
                    url.StopAccessingSecurityScopedResource();
            }
            return true;
        }
        return false;
    }
}
