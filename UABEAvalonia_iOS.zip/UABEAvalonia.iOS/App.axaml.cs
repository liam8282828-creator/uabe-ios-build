using Avalonia;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Markup.Xaml;
using UABEAvalonia.iOS.ViewModels;
using UABEAvalonia.iOS.Views;

namespace UABEAvalonia.iOS;

public class App : Application
{
    /// <summary>
    /// Referencia estática al ViewModel principal, accesible desde AppDelegate
    /// para enrutar la apertura de archivos externos (Files app, AirDrop, Share Sheet).
    /// </summary>
    public static MainViewModel? MainViewModel { get; private set; }

    public override void Initialize()
    {
        AvaloniaXamlLoader.Load(this);
    }

    public override void OnFrameworkInitializationCompleted()
    {
        MainViewModel = new MainViewModel();

        if (ApplicationLifetime is ISingleViewApplicationLifetime singleView)
        {
            // iOS usa SingleView (no multi-ventana de escritorio)
            singleView.MainView = new MainView
            {
                DataContext = MainViewModel
            };
        }

        base.OnFrameworkInitializationCompleted();
    }
}
