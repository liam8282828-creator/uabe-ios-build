using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Platform.Storage;
using UABEAvalonia.iOS.ViewModels;

namespace UABEAvalonia.iOS.Views;

/// <summary>
/// Code-behind de la vista principal.
/// La mayor parte de la lógica está en <see cref="MainViewModel"/>;
/// aquí solo se gestiona el file picker nativo de iOS (que no se puede
/// expresar en XAML sin un conversor especial).
/// </summary>
public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
    }

    /// <summary>
    /// Abre el selector de archivos nativo de iOS (UIDocumentPickerViewController).
    /// Avalonia lo expone a través de <c>IStorageProvider</c>.
    ///
    /// Se permiten todas las extensiones conocidas de Unity y archivos sin extensión
    /// (muchos AssetBundles no tienen extensión).
    /// </summary>
    private async void OnOpenFilePicker_Click(object? sender, RoutedEventArgs e)
    {
        var topLevel = TopLevel.GetTopLevel(this);
        if (topLevel?.StorageProvider is not { } sp) return;

        var options = new FilePickerOpenOptions
        {
            Title                  = "Abrir archivo Unity",
            AllowMultiple          = false,
            FileTypeFilter         = new[]
            {
                new FilePickerFileType("Unity Assets / AssetBundles")
                {
                    // iOS usa UTIs; "public.data" cubre archivos binarios arbitrarios.
                    // Es el tipo correcto para archivos .assets sin UTI registrado.
                    AppleUniformTypeIdentifiers = new[] { "public.data" },
                    Patterns = new[] { "*.assets", "*.bundle", "*.unity3d", "*.resource", "*" }
                },
                FilePickerFileTypes.All
            }
        };

        var files = await sp.OpenFilePickerAsync(options);
        if (files.Count == 0) return;

        var file = files[0];

        // IStorageFile.Path puede devolver null en iOS para archivos fuera del sandbox;
        // en ese caso usamos TryGetLocalPath() que acepta acceso a seguridad de scope.
        var path = file.TryGetLocalPath();
        if (path == null)
        {
            // Alternativa: copiar a una ubicación temporal del sandbox y abrir desde ahí.
            // Esto ocurre con archivos en iCloud Drive o en ubicaciones remotas.
            var tempPath = Path.Combine(Path.GetTempPath(), file.Name);
            await using var source = await file.OpenReadAsync();
            await using var dest   = new FileStream(
                tempPath,
                FileMode.Create,
                FileAccess.Write,
                FileShare.None,
                bufferSize: 4 * 1024 * 1024);
            await source.CopyToAsync(dest);
            path = tempPath;
        }

        if (DataContext is MainViewModel vm)
            await vm.OpenFileAsync(path);
    }
}
