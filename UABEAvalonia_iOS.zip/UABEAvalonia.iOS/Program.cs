using UIKit;

namespace UABEAvalonia.iOS;

/// <summary>
/// Punto de entrada nativo de iOS.
/// UIKit llama a UIApplicationMain, que instancia AppDelegate → Avalonia.
/// </summary>
public class Program
{
    // No se puede usar top-level statements en el target iOS; se requiere Main explícito.
    static void Main(string[] args)
    {
        UIApplication.Main(args, null, typeof(AppDelegate));
    }
}
