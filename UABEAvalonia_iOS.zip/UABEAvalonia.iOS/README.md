# UABEAvalonia.iOS

Versión iOS de UABEA (Unity Asset Bundle Extractor) construida con **Avalonia UI 11** y **AssetsTools.NET 3**.

---

## Estructura del proyecto

```
UABEAvalonia.iOS/
├── UABEAvalonia.iOS.csproj     ← Proyecto iOS (.NET 8 / net8.0-ios) con AOT activado
├── TrimmerRoots.xml            ← Protege ensamblados clave del tree-shaker AOT
├── Program.cs                  ← Punto de entrada (UIApplication.Main)
├── AppDelegate.cs              ← Integración Avalonia↔UIKit; gestiona apertura de archivos externos
├── App.axaml / App.axaml.cs   ← Application Avalonia (tema, recursos globales)
│
├── Platforms/iOS/
│   ├── Info.plist              ← Permisos UIFileSharingEnabled + LSSupportsOpeningDocumentsInPlace
│   └── Entitlements.plist      ← Entitlements de firma
│
├── Assets/
│   └── classdata.tpk           ← ⚠️ CÓPIAR MANUALMENTE desde el proyecto original
│
├── Models/
│   └── AssetEntry.cs           ← DTO ligero (solo metadatos; sin datos raw en RAM)
│
├── Logic/
│   ├── AssetFileOpener.cs      ← Apertura segura con FileStream (búfer segmentado 4 MB)
│   └── AssetImportExport.cs    ← Dump/Import de texto UABEA (compatible con streams)
│
├── ViewModels/
│   └── MainViewModel.cs        ← MVVM ReactiveUI: apertura, filtrado, exportación
│
└── Views/
    ├── MainView.axaml          ← UI móvil táctil (NavBar, SearchBar, ListBox, TabBar)
    └── MainView.axaml.cs       ← File picker nativo iOS (UIDocumentPickerViewController)
```

---

## Requisitos para compilar

| Herramienta | Versión mínima |
|---|---|
| .NET SDK | 8.0 (con workload `ios`) |
| Xcode | 15 o superior |
| macOS | 13 Ventura o superior |
| Apple Developer Account | Necesaria para firma y despliegue en dispositivo real |

### Instalar el workload iOS

```bash
dotnet workload install ios
```

---

## ⚠️ Paso obligatorio antes de compilar

Copia el archivo `classdata.tpk` de tu proyecto original al directorio `Assets/`:

```bash
cp /ruta/a/widmanios-main/classdata.tpk ./Assets/classdata.tpk
```

Elimina o ignora el archivo `Assets/classdata.tpk.placeholder`.

---

## Compilar y enviar al simulador

```bash
dotnet build UABEAvalonia.iOS.csproj -f net8.0-ios
dotnet run --project UABEAvalonia.iOS.csproj -f net8.0-ios
```

## Compilar para dispositivo real (requiere firma)

1. Abre `UABEAvalonia.iOS.csproj` y descomenta las líneas de firma:
   ```xml
   <CodesignKey>iPhone Developer</CodesignKey>
   <CodesignProvision>TU_PERFIL_DE_PROVISION</CodesignProvision>
   ```
2. Sustituye `com.tuempresa.uabeavalonia` por tu Bundle ID real.
3. Ejecuta:
   ```bash
   dotnet publish UABEAvalonia.iOS.csproj -f net8.0-ios -c Release
   ```

## Compilar .ipa para enviar al bot de Telegram

```bash
dotnet publish UABEAvalonia.iOS.csproj \
  -f net8.0-ios \
  -c Release \
  -r ios-arm64 \
  --self-contained true \
  -o ./publish

# El .ipa estará en ./publish/UABEAvalonia.iOS.ipa
```

---

## Funcionalidades implementadas

### ✅ Compatibilidad de interfaz iOS
- NavBar fija con safe area padding (52 pt top para el notch/Dynamic Island)
- SearchBar con estilo nativo iOS (fondo `#3A3A3C`, radio 10)
- ListBox con celdas de 44 pt mínimo (HIG de Apple)
- Tab Bar inferior con padding de 32 pt para el home indicator
- Soporte táctil nativo (Avalonia iOS maneja gestos automáticamente)
- Orientación portrait + landscape en iPhone e iPad

### ✅ Configuración iOS (.csproj)
- Target: `net8.0-ios`
- `MtouchLink=Full` + `PublishAot=true` → AOT completo
- `MtouchEnableSGenConc=true` → GC concurrente
- `TrimmerRoots.xml` protege AssetsTools.NET y Avalonia de la eliminación por AOT

### ✅ Info.plist
- `UIFileSharingEnabled = true` → carpeta Documents visible en Finder/iTunes
- `LSSupportsOpeningDocumentsInPlace = true` → abrir .assets de varios GB desde la app Archivos SIN copiarlos
- `CFBundleDocumentTypes` → registra extensiones `.assets`, `.bundle`, `.unity3d`

### ✅ Apertura segura con FileStream (sin ReadAllBytes)
- `AssetFileOpener.OpenAsync()` abre un `FileStream` con búfer de 4 MB
- AssetsTools.NET usa seeking sobre ese stream: **nunca se carga el archivo completo en RAM**
- Si el usuario abre desde la app Archivos, `AppDelegate.OpenUrl()` activa `StartAccessingSecurityScopedResource()` antes de pasar la ruta

### ✅ Dump/Import de texto UABEA
- Compatible con el formato original de UABEA desktop
- `ImportTextAsset()` acepta `Stream` (no `string` de ruta): evita archivos temporales grandes

---

## Permisos en Info.plist explicados

| Clave | Valor | Propósito |
|---|---|---|
| `UIFileSharingEnabled` | `true` | La carpeta `Documents` de la app aparece en Finder/iTunes cuando el iPhone está conectado al Mac. Los archivos exportados son accesibles sin jailbreak. |
| `LSSupportsOpeningDocumentsInPlace` | `true` | iOS abre el archivo `.assets` o AssetBundle **in-situ** desde su ubicación original (iCloud Drive, USB, etc.) sin hacer una copia. Esto es crítico para archivos de varios GB. |

---

## Limitaciones conocidas de iOS

| Limitación | Impacto | Mitigación en este proyecto |
|---|---|---|
| Sin acceso al sistema de archivos global | No se puede navegar `/var/mobile` | Se usa `UIDocumentPickerViewController` (Avalonia `IStorageProvider`) |
| Jetsam (límite de RAM por proceso) | App matada si usa demasiada RAM | `FileStream` + seeking; nunca `ReadAllBytes` |
| Sin shell / terminal | No se puede invocar herramientas externas | Todo el procesamiento es en proceso (AssetsTools.NET) |
| Sin escritura fuera de `Documents/` | Los exports deben ir a `Documents/` | `ExportSelectedAssetAsync` escribe en `Environment.SpecialFolder.MyDocuments` |
