namespace UABEAvalonia.iOS.Models;

/// <summary>
/// Representa un asset dentro de un archivo .assets o AssetBundle de Unity.
/// Esta clase es un Data Transfer Object (DTO) ligero; la lectura real del asset
/// se realiza bajo demanda mediante FileStream (nunca ReadAllBytes) para evitar
/// cargar assets de GB completos en la RAM de iOS.
/// </summary>
public sealed class AssetEntry
{
    /// <summary>Path ID único del asset dentro del archivo .assets.</summary>
    public long PathId { get; init; }

    /// <summary>Nombre del asset, tal como lo reporta AssetsTools.</summary>
    public string Name { get; init; } = string.Empty;

    /// <summary>Nombre del tipo de Unity (e.g. "Texture2D", "AudioClip", "Shader").</summary>
    public string TypeName { get; init; } = string.Empty;

    /// <summary>Índice del tipo dentro de la tabla de tipos del archivo.</summary>
    public int TypeIndex { get; init; }

    /// <summary>Tamaño del asset en bytes (leído de la cabecera; no requiere cargar datos).</summary>
    public long SizeBytes { get; init; }

    /// <summary>Tamaño formateado para mostrar en la UI (e.g. "12.4 MB").</summary>
    public string SizeDisplay => SizeBytes switch
    {
        < 1024              => $"{SizeBytes} B",
        < 1024 * 1024       => $"{SizeBytes / 1024.0:F1} KB",
        < 1024 * 1024 * 1024 => $"{SizeBytes / (1024.0 * 1024):F1} MB",
        _                   => $"{SizeBytes / (1024.0 * 1024 * 1024):F2} GB"
    };

    /// <summary>
    /// Descripción compacta para la celda de lista, al estilo iOS (título + subtítulo).
    /// </summary>
    public string Subtitle => $"{TypeName}  ·  {SizeDisplay}";
}
