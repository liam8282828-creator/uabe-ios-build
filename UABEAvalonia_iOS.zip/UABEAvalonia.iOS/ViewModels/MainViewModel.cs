using System.Collections.ObjectModel;
using System.Reactive;
using ReactiveUI;
using UABEAvalonia.iOS.Logic;
using UABEAvalonia.iOS.Models;

namespace UABEAvalonia.iOS.ViewModels;

/// <summary>
/// ViewModel raíz de la aplicación. Orquesta la apertura de archivos,
/// el estado de carga y la navegación entre assets.
/// </summary>
public sealed class MainViewModel : ReactiveObject, IDisposable
{
    private readonly AssetFileOpener _opener = new();

    // ── Propiedades reactivas ─────────────────────────────────────────────────

    private string  _statusText    = "Selecciona un archivo .assets o AssetBundle";
    private bool    _isLoading     = false;
    private int     _loadProgress  = 0;
    private string? _currentFile   = null;
    private string  _searchText    = string.Empty;
    private AssetEntry? _selected  = null;

    public string StatusText
    {
        get => _statusText;
        private set => this.RaiseAndSetIfChanged(ref _statusText, value);
    }

    public bool IsLoading
    {
        get => _isLoading;
        private set => this.RaiseAndSetIfChanged(ref _isLoading, value);
    }

    public int LoadProgress
    {
        get => _loadProgress;
        private set => this.RaiseAndSetIfChanged(ref _loadProgress, value);
    }

    public string? CurrentFile
    {
        get => _currentFile;
        private set => this.RaiseAndSetIfChanged(ref _currentFile, value);
    }

    public string SearchText
    {
        get => _searchText;
        set
        {
            this.RaiseAndSetIfChanged(ref _searchText, value);
            ApplyFilter();
        }
    }

    public AssetEntry? SelectedAsset
    {
        get => _selected;
        set => this.RaiseAndSetIfChanged(ref _selected, value);
    }

    // ── Colecciones ───────────────────────────────────────────────────────────

    /// <summary>Lista completa de assets (sin filtrar).</summary>
    private List<AssetEntry> _allAssets = new();

    /// <summary>Lista filtrada que la UI observa y presenta al usuario.</summary>
    public ObservableCollection<AssetEntry> FilteredAssets { get; } = new();

    // ── Comandos ──────────────────────────────────────────────────────────────

    public ReactiveCommand<Unit, Unit> CloseFileCommand { get; }
    public ReactiveCommand<AssetEntry, Unit> ExportAssetCommand { get; }

    public MainViewModel()
    {
        CloseFileCommand = ReactiveCommand.Create(CloseFile,
            this.WhenAnyValue(x => x.CurrentFile, f => f != null));

        ExportAssetCommand = ReactiveCommand.CreateFromTask<AssetEntry>(ExportSelectedAssetAsync,
            this.WhenAnyValue(x => x.CurrentFile, f => f != null));
    }

    // ── Apertura de archivos ──────────────────────────────────────────────────

    /// <summary>
    /// Abre un archivo desde una ruta absoluta.
    /// Llamado tanto desde el file picker de la UI como desde AppDelegate.OpenUrl
    /// cuando el usuario comparte un archivo desde "Archivos" (Files app).
    /// </summary>
    public void OpenFileFromPath(string path)
    {
        // Disparar sin await para no bloquear el hilo de UIKit
        _ = OpenFileAsync(path);
    }

    public async Task OpenFileAsync(string path)
    {
        if (IsLoading) return;

        try
        {
            IsLoading  = true;
            LoadProgress = 0;
            StatusText = $"Abriendo {Path.GetFileName(path)}…";
            FilteredAssets.Clear();
            _allAssets.Clear();

            var progress = new Progress<int>(p =>
            {
                // Actualizar siempre en el hilo UI de Avalonia
                Avalonia.Threading.Dispatcher.UIThread.Post(() => LoadProgress = p);
            });

            var entries = await _opener.OpenAsync(path, progress, CancellationToken.None);

            _allAssets  = entries;
            CurrentFile = path;
            StatusText  = $"{Path.GetFileName(path)}  ·  {entries.Count:N0} assets";

            ApplyFilter();
        }
        catch (OperationCanceledException)
        {
            StatusText = "Apertura cancelada.";
        }
        catch (Exception ex)
        {
            StatusText = $"Error al abrir: {ex.Message}";
        }
        finally
        {
            IsLoading    = false;
            LoadProgress = 0;
        }
    }

    // ── Filtrado ──────────────────────────────────────────────────────────────

    private void ApplyFilter()
    {
        FilteredAssets.Clear();
        var query = _searchText.Trim();

        var filtered = string.IsNullOrEmpty(query)
            ? _allAssets
            : _allAssets.Where(a =>
                a.Name.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                a.TypeName.Contains(query, StringComparison.OrdinalIgnoreCase));

        foreach (var entry in filtered)
            FilteredAssets.Add(entry);
    }

    // ── Exportar ─────────────────────────────────────────────────────────────

    private async Task ExportSelectedAssetAsync(AssetEntry entry)
    {
        if (CurrentFile == null) return;

        // Guardar en la carpeta Documents (accesible desde la app "Archivos" del iPhone)
        var docsDir  = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        var outPath  = Path.Combine(docsDir, $"{entry.Name}_{entry.PathId}.dat");

        StatusText = $"Exportando {entry.Name}…";
        try
        {
            await using var dest = new FileStream(
                outPath,
                FileMode.Create,
                FileAccess.Write,
                FileShare.None,
                bufferSize: 4 * 1024 * 1024);

            await _opener.ExportAssetRawAsync(entry, dest);
            StatusText = $"Exportado: {Path.GetFileName(outPath)}";
        }
        catch (Exception ex)
        {
            StatusText = $"Error al exportar: {ex.Message}";
        }
    }

    // ── Cerrar ────────────────────────────────────────────────────────────────

    private void CloseFile()
    {
        _opener.CloseCurrentFile();
        FilteredAssets.Clear();
        _allAssets.Clear();
        CurrentFile  = null;
        SelectedAsset = null;
        SearchText   = string.Empty;
        StatusText   = "Selecciona un archivo .assets o AssetBundle";
    }

    public void Dispose()
    {
        _opener.Dispose();
        CloseFileCommand.Dispose();
        ExportAssetCommand.Dispose();
    }
}
