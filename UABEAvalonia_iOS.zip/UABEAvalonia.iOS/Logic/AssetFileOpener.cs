using AssetsTools.NET;
using AssetsTools.NET.Extra;

namespace UABEAvalonia.iOS.Logic;

/// <summary>
/// Abre archivos .assets y AssetBundles de Unity usando exclusivamente <see cref="FileStream"/>
/// con búfer segmentado, evitando cualquier llamada a <c>File.ReadAllBytes</c> o equivalente.
///
/// ── ¿Por qué esto es crítico en iOS? ────────────────────────────────────────
/// iOS usa un límite de RAM duro (Jetsam) por proceso. Un archivo .assets de 4 GB
/// cargado completamente en un <c>byte[]</c> requiere al menos 4 GB contiguos en heap,
/// lo que garantiza que el kernel mate la app (SIGKILL / OOM) antes de que termine.
///
/// La solución es mantener el <see cref="FileStream"/> abierto y dejar que
/// AssetsTools.NET lea solo las porciones necesarias bajo demanda (streaming).
/// El búfer de 4 MB equilibra el número de syscalls con el uso de RAM.
/// ────────────────────────────────────────────────────────────────────────────
/// </summary>
public sealed class AssetFileOpener : IDisposable
{
    // Tamaño del búfer de lectura: 4 MB es un equilibrio seguro entre
    // rendimiento (menos llamadas al kernel) y consumo de RAM en iOS.
    private const int StreamBufferSize = 4 * 1024 * 1024; // 4 MB

    private readonly AssetsManager _manager;
    private FileStream?            _stream;
    private AssetsFileInstance?    _assetsFile;
    private BundleFileInstance?    _bundleFile;

    /// <summary>Ruta del archivo actualmente abierto.</summary>
    public string? CurrentFilePath { get; private set; }

    /// <summary>Indica si el archivo abierto es un AssetBundle (en lugar de un .assets plano).</summary>
    public bool IsBundle { get; private set; }

    public AssetFileOpener()
    {
        _manager = new AssetsManager();

        // Carga la base de datos de tipos de Unity que se incluye en el bundle de la app.
        // classdata.tpk permite resolver nombres y estructuras de tipos sin descompilar.
        var tpkPath = Path.Combine(
            AppContext.BaseDirectory,
            "classdata.tpk");

        if (File.Exists(tpkPath))
            _manager.LoadClassPackage(tpkPath);
    }

    /// <summary>
    /// Abre el archivo en <paramref name="filePath"/> usando un <see cref="FileStream"/>
    /// con búfer segmentado.
    ///
    /// <para>
    /// El stream permanece abierto durante toda la sesión de trabajo para que
    /// AssetsTools pueda hacer seeking sin cargar el archivo en RAM. Llama a
    /// <see cref="Dispose"/> (o use <c>using</c>) para liberar el handle del archivo.
    /// </para>
    /// </summary>
    /// <param name="filePath">Ruta absoluta al archivo .assets o AssetBundle.</param>
    /// <param name="progress">Progreso opcional 0-100 para actualizar la UI.</param>
    /// <param name="cancellationToken">Token de cancelación.</param>
    /// <returns>Lista de entradas de assets leídas de las cabeceras del archivo.</returns>
    /// <exception cref="InvalidOperationException">Si el archivo no es reconocible.</exception>
    public async Task<List<Models.AssetEntry>> OpenAsync(
        string filePath,
        IProgress<int>? progress = null,
        CancellationToken cancellationToken = default)
    {
        // Libera cualquier archivo previamente abierto
        CloseCurrentFile();

        CurrentFilePath = filePath;
        progress?.Report(5);

        // ── Paso 1: abrir el FileStream en modo lectura con búfer segmentado ──
        // FileOptions.SequentialScan sugiere al OS que optimice el caché para
        // lectura secuencial, lo que es beneficioso para archivos grandes.
        _stream = new FileStream(
            filePath,
            FileMode.Open,
            FileAccess.Read,
            FileShare.Read,
            bufferSize: StreamBufferSize,
            options: FileOptions.Asynchronous | FileOptions.SequentialScan);

        progress?.Report(15);

        // ── Paso 2: determinar si es un AssetBundle o un .assets plano ────────
        // Leemos solo los primeros bytes de la cabecera (< 100 bytes) para detectar
        // el formato, sin cargar el resto del archivo.
        var header = new byte[8];
        await _stream.ReadExactlyAsync(header, 0, 8, cancellationToken);
        _stream.Seek(0, SeekOrigin.Begin); // rebobinar para que AssetsTools lea desde el inicio

        // AssetsBundle comienza con "UnityFS" o "UnityRaw"; los .assets tienen otra firma.
        IsBundle = (header[0] == 'U' && header[1] == 'n' && header[2] == 'i');

        progress?.Report(25);

        cancellationToken.ThrowIfCancellationRequested();

        // ── Paso 3: cargar cabeceras (no los datos de los assets) ──────────────
        // AssetsTools lee solo la tabla de índices y los metadatos, NO los datos raw.
        // Los datos de cada asset se leen bajo demanda cuando el usuario los exporta.
        List<Models.AssetEntry> entries;

        if (IsBundle)
        {
            entries = await Task.Run(() => LoadBundle(progress), cancellationToken);
        }
        else
        {
            entries = await Task.Run(() => LoadAssetsFile(progress), cancellationToken);
        }

        progress?.Report(100);
        return entries;
    }

    // ── Carga un archivo .assets plano ────────────────────────────────────────
    private List<Models.AssetEntry> LoadAssetsFile(IProgress<int>? progress)
    {
        // LoadAssetsFile acepta un Stream; AssetsTools.NET hace seeking interno.
        // NUNCA se carga el contenido completo del archivo en memoria.
        _assetsFile = _manager.LoadAssetsFile(_stream!, CurrentFilePath!, false);
        _manager.LoadClassDatabaseFromPackage(_assetsFile.file.Metadata.UnityVersion);

        progress?.Report(60);

        var result = new List<Models.AssetEntry>();
        var infos  = _assetsFile.file.AssetInfos;

        for (int i = 0; i < infos.Count; i++)
        {
            var info = infos[i];

            // Obtener nombre del tipo desde la base de tipos (no requiere cargar el asset)
            string typeName = _manager.GetTypeInstance(
                _assetsFile, info)?.GetBaseField()?.TypeName ?? $"TypeId({info.TypeId})";

            // Leer nombre del asset: AssetsTools hace un seek puntual, lee unos bytes.
            string assetName = string.Empty;
            try
            {
                var baseField = _manager.GetTypeInstance(_assetsFile, info)?.GetBaseField();
                assetName = baseField?["m_Name"]?.AsString ?? string.Empty;
            }
            catch { /* assets sin campo m_Name son válidos (e.g. shaders, scripts) */ }

            result.Add(new Models.AssetEntry
            {
                PathId    = info.PathId,
                Name      = string.IsNullOrEmpty(assetName) ? $"PathID({info.PathId})" : assetName,
                TypeName  = typeName,
                TypeIndex = info.TypeId,
                SizeBytes = info.ByteSize
            });

            // Reportar progreso cada 200 assets para no saturar el hilo UI
            if (i % 200 == 0)
                progress?.Report(60 + (int)(30.0 * i / infos.Count));
        }

        return result;
    }

    // ── Carga un AssetBundle ──────────────────────────────────────────────────
    private List<Models.AssetEntry> LoadBundle(IProgress<int>? progress)
    {
        // LoadBundleFile acepta un Stream directamente; el contenido del bundle
        // NO se descomprime completamente en RAM: AssetsTools usa decompresión
        // por bloques internamente.
        _bundleFile = _manager.LoadBundleFile(_stream!, CurrentFilePath!);

        progress?.Report(40);

        // Descomprimir solo el primer archivo .assets del bundle en un MemoryStream.
        // En bundles grandes esto puede ser cientos de MB, pero es inevitable para
        // leer la tabla de índices. El stream de datos raw SÍ se libera al terminar.
        using var unpackedStream = new MemoryStream();
        _manager.UnpackBundleToStream(_bundleFile, unpackedStream);

        progress?.Report(55);

        unpackedStream.Seek(0, SeekOrigin.Begin);
        _assetsFile = _manager.LoadAssetsFileFromBundle(_bundleFile, 0, false);

        if (_assetsFile == null)
            throw new InvalidOperationException("No se encontró ningún .assets dentro del bundle.");

        _manager.LoadClassDatabaseFromPackage(_assetsFile.file.Metadata.UnityVersion);

        progress?.Report(65);

        return BuildEntriesFromAssetsFile(progress, 65);
    }

    // ── Helpers compartidos ───────────────────────────────────────────────────

    private List<Models.AssetEntry> BuildEntriesFromAssetsFile(IProgress<int>? progress, int baseProgress)
    {
        var result = new List<Models.AssetEntry>();
        var infos  = _assetsFile!.file.AssetInfos;

        for (int i = 0; i < infos.Count; i++)
        {
            var    info     = infos[i];
            string typeName = _manager.GetTypeInstance(_assetsFile, info)?.GetBaseField()?.TypeName
                              ?? $"TypeId({info.TypeId})";

            string assetName = string.Empty;
            try
            {
                var baseField = _manager.GetTypeInstance(_assetsFile, info)?.GetBaseField();
                assetName = baseField?["m_Name"]?.AsString ?? string.Empty;
            }
            catch { }

            result.Add(new Models.AssetEntry
            {
                PathId    = info.PathId,
                Name      = string.IsNullOrEmpty(assetName) ? $"PathID({info.PathId})" : assetName,
                TypeName  = typeName,
                TypeIndex = info.TypeId,
                SizeBytes = info.ByteSize
            });

            if (i % 200 == 0)
                progress?.Report(baseProgress + (int)((100 - baseProgress) * 0.9 * i / infos.Count));
        }

        return result;
    }

    /// <summary>
    /// Exporta el contenido raw de un asset concreto a un Stream de destino usando
    /// seeking sobre el FileStream original. NO carga el asset completo en RAM.
    /// </summary>
    public async Task ExportAssetRawAsync(
        Models.AssetEntry entry,
        Stream destination,
        CancellationToken cancellationToken = default)
    {
        if (_assetsFile == null || _stream == null)
            throw new InvalidOperationException("No hay ningún archivo abierto.");

        var info = _assetsFile.file.AssetInfos.FirstOrDefault(a => a.PathId == entry.PathId)
                   ?? throw new KeyNotFoundException($"PathID {entry.PathId} no encontrado.");

        // Posicionar el stream en el offset del asset y copiar solo sus bytes
        _stream.Seek(
            _assetsFile.file.Header.DataOffset + info.ByteOffset,
            SeekOrigin.Begin);

        await _stream.CopyToAsync(destination, StreamBufferSize, cancellationToken);
    }

    /// <summary>Cierra el archivo actual liberando el FileStream.</summary>
    public void CloseCurrentFile()
    {
        _assetsFile  = null;
        _bundleFile  = null;
        _stream?.Dispose();
        _stream      = null;
        CurrentFilePath = null;
        IsBundle     = false;
    }

    public void Dispose()
    {
        CloseCurrentFile();
        _manager.UnloadAll(true);
    }
}
