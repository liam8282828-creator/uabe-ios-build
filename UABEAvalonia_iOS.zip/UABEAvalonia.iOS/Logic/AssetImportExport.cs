// Adaptado de UABEA (github.com/nesrak1/UABEA) — lógica de importación/exportación de texto.
// Modificaciones iOS:
//  - Se eliminan referencias a Avalonia.Desktop y al sistema de diálogos de escritorio.
//  - La escritura de dumps se realiza siempre a través de streams para evitar archivos temporales
//    grandes en la RAM (iOS tiene límites estrictos por proceso).
//  - El método ImportTextAsset acepta un Stream en lugar de una ruta de archivo.
using AssetsTools.NET;
using AssetsTools.NET.Extra;
using System.Text;

namespace UABEAvalonia.iOS.Logic;

public class AssetImportExport
{
    private TextReader    _sr = null!;
    private AssetsFileWriter _aw = null!;

    // ─── Text Dump Export ─────────────────────────────────────────────────────

    /// <summary>
    /// Vuelca los campos del asset a <paramref name="sw"/> en formato texto UABEA.
    /// Escribe de forma incremental (campo a campo), nunca acumula en memoria.
    /// </summary>
    public void DumpTextAsset(StreamWriter sw, AssetTypeValueField baseField)
        => RecurseTextDump(sw, baseField, 0);

    private void RecurseTextDump(StreamWriter sw, AssetTypeValueField field, int depth)
    {
        var    template  = field.TemplateField;
        string align     = template.IsAligned ? "1" : "0";
        string typeName  = template.Type;
        string fieldName = template.Name;
        bool   isArray   = template.IsArray;

        if (template.ValueType == AssetValueType.String)
            align = "1";

        if (isArray)
        {
            var    sizeTemplate  = template.Children[0];
            string sizeAlign     = sizeTemplate.IsAligned ? "1" : "0";
            string sizeTypeName  = sizeTemplate.Type;
            string sizeFieldName = sizeTemplate.Name;

            if (template.ValueType != AssetValueType.ByteArray)
            {
                int size = field.AsArray.size;
                sw.WriteLine($"{new string(' ', depth)}{align} {typeName} {fieldName} ({size} items)");
                sw.WriteLine($"{new string(' ', depth + 1)}{sizeAlign} {sizeTypeName} {sizeFieldName} = {size}");
                for (int i = 0; i < field.Children.Count; i++)
                {
                    sw.WriteLine($"{new string(' ', depth + 1)}[{i}]");
                    RecurseTextDump(sw, field.Children[i], depth + 2);
                }
            }
            else
            {
                byte[] data = field.AsByteArray;
                int    size = data.Length;
                sw.WriteLine($"{new string(' ', depth)}{align} {typeName} {fieldName} ({size} items)");
                sw.WriteLine($"{new string(' ', depth + 1)}{sizeAlign} {sizeTypeName} {sizeFieldName} = {size}");
                for (int i = 0; i < size; i++)
                {
                    sw.WriteLine($"{new string(' ', depth + 1)}[{i}]");
                    sw.WriteLine($"{new string(' ', depth + 2)}0 UInt8 data = {data[i]}");
                }
            }
        }
        else
        {
            string value = "";
            if (field.Value != null)
            {
                var evt = field.Value.ValueType;
                if (evt == AssetValueType.String)
                    value = $" = \"{EscapeString(field.AsString)}\"";
                else if ((int)evt >= 1 && (int)evt <= 12)
                    value = $" = {field.AsString}";
            }
            sw.WriteLine($"{new string(' ', depth)}{align} {typeName} {fieldName}{value}");

            foreach (AssetTypeValueField? child in field)
                RecurseTextDump(sw, child, depth + 1);
        }
    }

    // ─── Text Dump Import ─────────────────────────────────────────────────────

    /// <summary>
    /// Importa un dump de texto UABEA desde <paramref name="sourceStream"/>.
    /// Lee el stream línea a línea: nunca acumula el texto completo en un string.
    /// Devuelve los bytes binarios resultantes en un <see cref="MemoryStream"/> pequeño
    /// (solo los datos modificados de ese asset, no el archivo completo).
    /// </summary>
    public byte[]? ImportTextAsset(Stream sourceStream, out string? exceptionMessage)
    {
        using var reader = new StreamReader(sourceStream, Encoding.UTF8, leaveOpen: true);
        _sr = reader;

        using var ms = new MemoryStream();
        _aw = new AssetsFileWriter(ms);
        _aw.BigEndian = false;

        try
        {
            ImportTextAssetLoop();
            exceptionMessage = null;
        }
        catch (Exception ex)
        {
            exceptionMessage = ex.Message;
            return null;
        }
        return ms.ToArray();
    }

    private void ImportTextAssetLoop()
    {
        var alignStack = new Stack<bool>();

        while (true)
        {
            string? line = _sr.ReadLine();
            if (line == null) return;

            int thisDepth = 0;
            while (thisDepth < line.Length && line[thisDepth] == ' ')
                thisDepth++;

            if (thisDepth >= line.Length) continue;
            if (line[thisDepth] == '[') continue; // índice de array — saltar

            while (thisDepth < alignStack.Count)
            {
                if (alignStack.Pop()) _aw.Align();
            }

            bool align    = line.Substring(thisDepth, 1) == "1";
            int  typeStart = thisDepth + 2;
            int  eqSign   = line.IndexOf('=');

            if (eqSign != -1)
            {
                string valueStr = line[(eqSign + 1)..].Trim();
                string check    = line[typeStart..];

                if      (StartsWithToken(check, "int"))               _aw.Write(int.Parse(valueStr));
                else if (StartsWithToken(check, "float"))             _aw.Write(float.Parse(valueStr, System.Globalization.CultureInfo.InvariantCulture));
                else if (StartsWithToken(check, "bool"))              _aw.Write(bool.Parse(valueStr));
                else if (StartsWithToken(check, "SInt64"))            _aw.Write(long.Parse(valueStr));
                else if (StartsWithToken(check, "string"))
                {
                    int fq  = valueStr.IndexOf('"');
                    int lq  = valueStr.LastIndexOf('"');
                    string raw = (fq >= 0 && lq > fq) ? valueStr[(fq + 1)..lq] : valueStr;
                    _aw.WriteCountStringInt32(UnescapeString(raw));
                }
                else if (StartsWithToken(check, "UInt8"))             _aw.Write(byte.Parse(valueStr));
                else if (StartsWithToken(check, "unsigned int"))      _aw.Write(uint.Parse(valueStr));
                else if (StartsWithToken(check, "UInt16"))            _aw.Write(ushort.Parse(valueStr));
                else if (StartsWithToken(check, "SInt8"))             _aw.Write(sbyte.Parse(valueStr));
                else if (StartsWithToken(check, "SInt16"))            _aw.Write(short.Parse(valueStr));
                else if (StartsWithToken(check, "UInt64"))            _aw.Write(ulong.Parse(valueStr));
                else if (StartsWithToken(check, "double"))            _aw.Write(double.Parse(valueStr, System.Globalization.CultureInfo.InvariantCulture));
                else if (StartsWithToken(check, "char"))              _aw.Write(sbyte.Parse(valueStr));
                else if (StartsWithToken(check, "FileSize"))          _aw.Write(ulong.Parse(valueStr));
                else if (StartsWithToken(check, "short"))             _aw.Write(short.Parse(valueStr));
                else if (StartsWithToken(check, "long"))              _aw.Write(long.Parse(valueStr));
                else if (StartsWithToken(check, "SInt32"))            _aw.Write(int.Parse(valueStr));
                else if (StartsWithToken(check, "UInt32"))            _aw.Write(uint.Parse(valueStr));
                else if (StartsWithToken(check, "unsigned char"))     _aw.Write(byte.Parse(valueStr));
                else if (StartsWithToken(check, "unsigned short"))    _aw.Write(ushort.Parse(valueStr));
                else if (StartsWithToken(check, "unsigned long long")) _aw.Write(ulong.Parse(valueStr));

                if (align) _aw.Align();
            }
            else
            {
                alignStack.Push(align);
            }
        }
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    private static bool StartsWithToken(string str, string token)
        => str.StartsWith(token + " ", StringComparison.Ordinal);

    private static string EscapeString(string s)
        => s.Replace("\\", "\\\\").Replace("\r", "\\r").Replace("\n", "\\n");

    private static string UnescapeString(string s)
    {
        var  sb  = new StringBuilder(s.Length);
        bool esc = false;
        foreach (char c in s)
        {
            if (!esc && c == '\\') { esc = true; continue; }
            if (esc)
            {
                sb.Append(c switch { '\\' => '\\', 'r' => '\r', 'n' => '\n', _ => c });
                esc = false;
            }
            else sb.Append(c);
        }
        return sb.ToString();
    }
}
